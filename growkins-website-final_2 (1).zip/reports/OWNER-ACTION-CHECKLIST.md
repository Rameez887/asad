# GROWKINS — Owner-Input Checklist (updated after final round)

> **Resolved since first version:** primary domain (`www.growkins.com` applied everywhere), business email (`info@growkins.com`), favicon/touch icons/manifest (created and linked). **Still open:** booking URL, social profile URLs, analytics/Search Console/pixels, form endpoint + CRM (WordPress stage), legal-entity confirmation, and verified proof assets (case studies, testimonials, client logos — supply real ones; nothing was fabricated).

---

# Original checklist (historical)

These items were **deliberately left unchanged** because no confirmed replacement values were supplied. Nothing was invented. Current working values remain in the build so nothing breaks. Provide the confirmed values below and they can be swapped in with a single follow-up pass.

## 1. Domain and URLs — OWNER ACTION REQUIRED

The entire site (canonical URLs, Open Graph URLs, JSON-LD, sitemap.xml, robots.txt) still points at the current domain `https://www.leadsreps.com`. `growkins.com` was **not** assumed or invented.

```
New primary domain:              ______________________
New canonical domain:            ______________________
New business email:              ______________________
New booking URL:                 ______________________  (current: www.leadsreps.com/#contact reference in the ICP worksheet PDF)
New LinkedIn company URL:        ______________________  (none present in build — schema sameAs is empty)
New Facebook URL:                ______________________  (none present in build)
New Instagram URL:               ______________________  (none present in build)
New X/Twitter URL:               ______________________  (none present in build)
New analytics property:          ______________________  (no analytics tags present in build)
New Search Console property:     ______________________
```

Locations of domain references (all preserved as-is): `<link rel="canonical">`, `og:url`, `og:image`, `twitter:image` and JSON-LD `url`/`logo` on all 43 pages; every `<loc>` in `sitemap.xml`; the `Sitemap:` line in `robots.txt`; the strategy-call link and email inside `assets/downloads/growkins-icp-worksheet.pdf`.

## 2. Email addresses — OWNER ACTION REQUIRED — provide the confirmed GROWKINS email address

`hello@leadsreps.com` appears in: `company/contact.html` (visible contact info), `source/revenue-growth-site.html` (source master), and the ICP worksheet PDF (page 6). No new address was invented; the current working address remains.

## 3. Renamed page URLs — redirects needed if the old URLs were ever live

- `company/why-leadsreps.html` → `company/why-growkins.html`
- `company/the-leadsreps-method.html` → `company/the-growkins-method.html`

All internal links, sitemap entries, and source-master SPA routes were updated (link check: 5,552 relative references, 0 broken). If these pages were ever published at the old URLs, add 301 redirects at the host/WordPress level.

## 4. Legal entity — CONFIRM

The site uses the brand name (not a registered legal entity with a suffix) throughout the legal pages, copyright notices, and the Data Processing Agreement. All such public-facing brand references now read GROWKINS, e.g. "© 2026 GROWKINS. All rights reserved." **If the registered legal entity differs from the public brand**, the legal pages — Privacy Policy, Acceptable Use Policy, Disclaimer, Data Processing Agreement, Accessibility Statement — should be reviewed by the owner/legal counsel and the registered name inserted where required. No registration number, registered address, jurisdiction, or entity suffix was invented.

## 5. Favicon — none exists in the build

The current site ships no favicon, apple-touch-icon, or manifest (the browser's automatic `/favicon.ico` request 404s — a pre-existing condition, unchanged by the rebrand). No old-brand monogram exists to replace. Recommended: add a favicon using the existing blue rounded-square + white chart-arrow logo mark (it is brand-neutral and works for GROWKINS), or a "G" monogram in the existing color system. Flagged in the WordPress migration checklist.

## 6. Forms / integrations / analytics

The contact page and site contain no form endpoints, webhook URLs, CRM labels, analytics tags, tracking IDs, or third-party integration identifiers (static export — forms are handled at the WordPress build stage). Nothing required changing; the WordPress migration checklist covers form notification subjects, confirmation messages, and sender names for the WordPress build.
