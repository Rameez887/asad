# Brand Replacement Report — LeadsReps → GROWKINS

**Date:** 2026-08-05 · **Scope:** controlled company-name update only. No redesign, no copy rewrite, no structural, visual, or functional changes.

## What was replaced

| Old form | New form | Where |
|---|---|---|
| `LeadsReps` (1,195×) | `GROWKINS` | Visible copy, text logo, titles, meta descriptions, OG/Twitter tags, `og:site_name`, JSON-LD (Organization "GROWKINS Growth Partners", WebSite, WebPage, Service, FAQ, Breadcrumb, publisher/provider/copyrightHolder), aria-labels, copyright notices, legal pages, docs |
| `LEADSREPS` (3×) | `GROWKINS` | PDF header; JS constant `LEADSREPS_METHOD` → `GROWKINS_METHOD` in the source master |
| `why-leadsreps` slug | `why-growkins` | Page file renamed + every internal link, sitemap `<loc>`, and SPA route (owner-approved) |
| `the-leadsreps-method` slug | `the-growkins-method` | Page file renamed + every internal link, sitemap `<loc>`, and SPA route (owner-approved) |
| `leadsreps-icp-worksheet.pdf` | `growkins-icp-worksheet.pdf` | Asset renamed and regenerated; all references updated |
| OG image (raster) | Regenerated | Same 1200×630 design, navy/blue/lime system, now displays GROWKINS |
| Docx filenames | `GROWKINS-…` | Both documentation files renamed; contents and metadata rebranded |

Variants searched and not found anywhere: `Leads Reps`, `LEADS REPS`, `leads reps`, `Leads-reps`, `leads-reps` (outside slugs above), `Leads_Reps`, `leads_reps`.

## What was deliberately NOT changed

- **Marketing uses of "leads"** — qualified leads, B2B leads, lead generation, sales leads, lead research, lead quality, lead qualification, and all page slugs like `saas-lead-generation.html` are service terminology and remain untouched (verified by byte-level replay: only brand tokens differ from the original files).
- **Domain** `leadsreps.com` in canonicals, OG URLs, JSON-LD, sitemap, robots.txt — no new domain was invented (see OWNER-ACTION-CHECKLIST.md).
- **Email** `hello@leadsreps.com` — no new address was invented.
- **All content, layout, design tokens (navy/blue/lime/white/grey), typography, icons, infographics, forms, ROI-calculator logic, navigation and footer structure, section order, SEO copy, schema types, internal-link strategy, responsive behaviour.**
- **Brand-neutral CSS classes** (`.service-card`, `.hero-section`, `.logo`, etc.) — no CSS selector contained the old brand name, so zero CSS churn.
- **The logo mark** — the blue rounded-square + white chart-arrow SVG is brand-neutral and was retained exactly as-is; only the HTML logo text changed.
- **"LR" search** — reviewed; no old-brand "LR" monogram or initialism exists anywhere in the project.

## Verification method

1. Ordered, domain-protected token replacement (domain masked before brand substitution, restored after) across all 50 text files.
2. Byte-level replay: the same rules applied to the pristine originals reproduce the delivered files exactly — **0 unexpected differences**, proving no copy was rewritten.
3. Case-insensitive residual sweep for all brand variants: **0 remaining** outside the deliberately preserved domain/email and one intentional explanatory mention in the WordPress migration checklist.
4. Full browser QA (see QA-REPORT.md).
