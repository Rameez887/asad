# QA Report — GROWKINS Rebrand

**Method:** automated project-wide searches, byte-level replay verification, JSON-LD parsing, a full relative-reference link check, and a headless-Chromium sweep of rendered pages (desktop 1280px and mobile 390px).

## Residual brand search (case-insensitive)

Searched: `LeadsReps`, `Leads Reps`, `leadsreps`, `leads reps`, `leads-reps`, `leads_reps`, `LR` — across all file contents **and** filenames, including rendered page text, page source, metadata, JSON-LD, and documentation.

- **0 residual brand references** outside the three intentional preservations: the `leadsreps.com` domain (canonical/OG/sitemap/robots — owner must confirm new domain), `hello@leadsreps.com` (owner must confirm new email), and one explanatory "changed from LeadsReps to GROWKINS" line in the new WordPress migration checklist.
- "LR" review: no old-brand monogram exists; remaining "lr" hits are unrelated code/word fragments only.
- Marketing "leads" phrases verified intact (e.g. index.html still contains 11 "lead generation" instances, unchanged).

## Integrity verification

- **Byte-level replay:** applying the replacement rules to the pristine originals reproduces every delivered text file exactly — 50/50 files, 0 unexpected differences. No copy, claims, statistics, CTAs, or structure changed.
- **Link check:** 5,552 relative href/src references across all 43 pages — **0 broken** (matches the pre-rebrand baseline count of 5,552).
- **JSON-LD:** all 78 structured-data blocks parse as valid JSON after editing.

## Rendered-page checks (headless Chromium)

Pages tested: home, Why GROWKINS, The GROWKINS Method, About, Contact, ROI calculator, Lead Generation service, SaaS industry, Privacy Policy, Insights.

| Check | Result |
|---|---|
| All tested pages load (HTTP 200) | PASS |
| Browser tab titles show GROWKINS | PASS |
| Header/nav text logo renders "GROWKINS" (desktop + mobile) | PASS |
| No visible old brand in rendered body text (Contact page shows only the preserved hello@leadsreps.com email) | PASS |
| JavaScript console errors | 0 (the only network 404 is the browser's automatic /favicon.ico probe — pre-existing; the site has never shipped a favicon) |
| Mobile menu opens at 390px | PASS |
| Dropdown navigation markup intact (unchanged from original) | PASS |
| ROI calculator computes (14 controls, live $ outputs) | PASS |
| Renamed pages why-growkins.html / the-growkins-method.html load with working nav | PASS |
| Responsive layout | Unchanged — zero layout/CSS edits were made (verified by replay) |

## Assets

- **og-image.png** — regenerated at 1200×630, same design system (navy background, blue logo mark, white headline, lime subtitle), displays GROWKINS. Same filename, so all 87 metadata references remain valid.
- **growkins-icp-worksheet.pdf** — regenerated 6-page worksheet, same ReportLab design and identical content; text extraction verified (no broken glyphs, arrows render correctly); PDF metadata Title/Author now GROWKINS. Old file removed; all references updated.
- **No favicon exists in the project** (pre-existing) — nothing to replace; flagged in the owner checklist and WordPress migration checklist.
- All SVGs are inline and brand-neutral (logo mark, icons) — untouched, none broken.

## Known items outside QA scope

Domain, email, booking URL, social profiles, analytics properties, and legal-entity confirmation are pending owner input — see OWNER-ACTION-CHECKLIST.md.
