# Visual Storytelling & Pipeline Transparency Round — QA Report

**Accuracy confirmation up front:** no client names, logos, testimonials, revenue figures, meeting counts, deal counts, conversion or reply rates, customer numbers, years in business, team sizes, awards, reviews, guarantees, partnerships, certifications, or case-study outcomes were invented in this round. The pipeline funnel is **process-only** (Option B in the brief) — it shows stages and their outputs, never volumes. The only numbers anywhere on the homepage are live ROI-calculator outputs computed from user-entered assumptions, now explicitly flagged.

---

## 1. Homepage section changes

Final sequence (14 sections, matching the Part 18 order):

1. Hero — category, outcome, mechanism, CTAs
2. Early trust and operating evidence
3. Core prospecting problems ("Sound familiar?")
4. **Pipeline outcome visualization** (new)
5. **Three solution groups** (replaces the flat 8-card grid)
6. GROWKINS Outbound Operating System (now phase-grouped)
7. **Engagement deliverables** (new)
8. Campaign team
9. Launch timeline
10. ROI calculator
11. Priority industries
12. Differentiators
13. Resources
14. Service-fit guide → final CTA

**Hero (Part 1):** category label changed to "B2B Outbound Sales & Appointment Setting"; supporting copy now states the mechanism and the division of labour ("…turning defined markets into qualified sales conversations. Your team focuses on the conversations and the close."); secondary CTA changed to **"Explore the Outbound System"**, anchored to `#outbound-system` (the new pipeline section); expectation line added beneath the CTAs: "30-minute strategy call focused on your market, pipeline gaps, and best-fit outbound approach."

**Problems (Part 4):** transition line added beneath the three diagnostic groups — "GROWKINS addresses these issues through one connected outbound operating system."

## 2. Pipeline visualization (Parts 2 & 3)

New dark panel, `#outbound-system`, titled **"How your pipeline can work with GROWKINS."**

- **Left — what GROWKINS manages:** three CSS-only tabs (Target and Engage / Activate and Qualify / Handoff and Optimize) revealing 8, 6, and 6 concrete activities respectively. Built from radio inputs + labels, so it is natively keyboard-operable with **no JavaScript added**.
- **Right — the journey, stage by stage:** Target Accounts → Verified Buyers → Engaged Prospects → Qualified Conversations → Sales Meetings, each with its process output (defined account universe, verified buyer contacts, active conversations, criteria-checked interest, booked CRM-ready meetings).
- **Explicit ownership boundary:** a lime-bordered "GROWKINS manages" zone, a handoff bar ("Qualified meeting handoff, with full CRM context"), then a blue-bordered "Your sales team manages" zone containing Client-Owned Opportunities and Closed Deals.
- **No fabricated numbers.** Panel footer states: "Stages describe the process and its outputs — not projected volumes," with a **Model Your Scenario** button to the ROI calculator (Option A path for anyone wanting figures, driven entirely by their own inputs).
- The channel-selection criteria (industry, account value, buyer seniority, sales-cycle complexity, market maturity, available data, team capacity) plus the "not every campaign uses every channel" caveat were folded into this panel.

## 3. Operating system (Part 6)

Restructured from a flat 14-tile grid into **four labelled phases — Strategy, Campaign Build, Execution, Optimization — with 16 stages**, each showing a description *and* a deliverable tag (Campaign brief, ICP document, Approved messaging, Verified records, Qualified leads, CRM-ready records, Campaign report, Updated targeting, Scaled campaign…). Links through to the full engagement process page.

## 4. Solution groups (Part 5)

The eight equal service cards became three needs-based groups: **Build the Target Market** (Lead Generation, ABM), **Create Sales Conversations** (Cold Email, LinkedIn, Cold Calling, Appointment Setting), **Expand Outbound Capacity** (SDR as a Service, Outbound Sales). Every service still links to its own unchanged page; no service page was renamed or deleted. The compact need→solution selection table remains later in the page. The same grouping was added to the Services hub.

## 5. Deliverables (Part 7)

New **"What your GROWKINS engagement includes"** — twelve concrete assets: ICP and segmentation document, account and contact research, verified prospect database, campaign messaging, outreach sequences, calling and LinkedIn scripts, reply management, qualification framework, calendar coordination, CRM-ready lead context, performance reporting, optimization recommendations.

## 6. Team & timeline (Parts 8 & 9)

Both were built in the previous round and verified intact: five specialist role cards with Owns / You-get lines, and the Week 1 → Month 2+ roadmap with the "timelines vary by service and campaign complexity" disclaimer.

## 7. ROI calculator (Part 10)

Both calculator surfaces (homepage mini-calculator and the full calculator page) now carry the flag: **"Illustrative projection based only on the assumptions you enter — not a guarantee or a historical GROWKINS result."** A **"Review This Scenario With GROWKINS"** CTA was added after the results. Calculator logic itself is untouched.

## 8. Case-study page (Parts 11 & 12)

H1 is now **"Outbound Campaign Frameworks and Success Stories."** The page opens with a brief, honest **Verified Success Stories** section ("Verified customer stories will be added as publication permissions are secured"), followed by the three detailed **Illustrative Campaign Frameworks** (Cybersecurity SaaS, Recruitment, Logistics), each card carrying the flag **"Illustrative strategy example — not a customer result."** A reusable case-study template specification (14 fields + 6 components, publish-only-when-verified rule) was added to the WordPress developer instructions.

## 9. Copy reduction & consolidation

| Page | Before | After | Change |
|---|---|---|---|
| Why GROWKINS | 1,757 | 1,647 | **−110 words** (two near-duplicate sections merged: "We work inside your stack" + "…your process"; restating opener removed) |
| Homepage | 1,897 | 2,008 | +111 words, but **one fewer section** and far more explanatory structure |

**Sections deleted or consolidated:**
- Removed: the dark 7-step "How GROWKINS Builds Your Pipeline" flow — fully superseded by the phase-grouped operating system.
- Removed: the standalone omnichannel section — its journey duplicated the new funnel; its channel-selection criteria were folded into the pipeline panel.
- Replaced: "Outcomes, not activity" benefit grid → pipeline visualization; 8-card service grid → three solution groups.
- Merged (Why GROWKINS): the two "we work inside your…" sections into one.

The homepage's modest word increase buys the pipeline visualization, the deliverables list, and the phase labels — the density is now in structured, scannable components rather than paragraphs.

## 10. New explanatory visuals added this round

1. Pipeline funnel with managed vs client-owned zones and handoff bar (homepage)
2. Three-phase tabbed "what GROWKINS manages" panel (homepage)
3. Solution-group cards with per-service links (homepage + Services hub)
4. Phase-grouped operating-system grid with deliverable tags (homepage)
5. Deliverables grid (homepage)
6. Calculator illustrative-projection flags (homepage + calculator page)
7. Verified-vs-illustrative split on the frameworks page

Existing explanatory visuals retained: trust bar, team role cards, engagement timeline, service-fit table, per-service workflow maps (8), industry buyer journeys (16), industry hero scenes (4 structural families), campaign framework cards (3).

## 11. Navigation verification (Part 19)

| Viewport | Services menu | Industries menu | Result |
|---|---|---|---|
| 1366×768 | 3-col grid (overview + 2 link cols) | 8 industries + "View all industries →" | PASS |
| 1440×900 | same | same | PASS |
| 1920×1080 | same | same | PASS |
| 1242×698 (≈110% zoom) | same | same | PASS |
| 1093×614 (≈125% zoom) | same | same | PASS |
| 911×512 (≈150% zoom) | below the 960px breakpoint → mobile accordion takes over (by design) | — | PASS |

Both menus measure 720px wide with no internal scrolling, no clipping, and no cut-off descriptions at any tested size. "View all industries →" resolves to `industries/industries.html`. Keyboard: focusing the trigger opens the menu, Tab moves into the items, focus ring visible, menu closes on blur. Mobile accordion unchanged and still lists **all 36 sub-links** — no industry page was removed from navigation, the sitemap, or the internal-link graph.

## 12. Full QA results

- **Rendering sweep:** 43 pages × 7 viewports (1366×768, 1440×900, 1920×1080, 1242, 1093, 911, 390 mobile) — **0 failures**: no console errors, no HTTP/asset errors, zero horizontal overflow anywhere.
- **SEO preservation:** exactly one H1 per page; zero duplicate title tags; every canonical on `www.growkins.com`; all 78 JSON-LD blocks valid; sitemap, robots.txt, meta titles/descriptions, URLs and slugs unchanged; no page renamed or duplicated.
- **Links & assets:** 5,798 internal references checked, **0 broken**, no missing assets.
- **Old-brand references:** none.
- **Unsupported-claim scan:** the only numeric matches site-wide are ROI-calculator outputs and the clearly-labelled "typical benchmark conversion rates" note attached to the calculator — both now carry the illustrative-projection flag. No performance claim is presented as GROWKINS history.
- **Accessibility:** decorative SVGs remain `aria-hidden="true"`; the pipeline tabs use real radio inputs (keyboard-operable, focus-visible outline); reduced-motion support unchanged; no JavaScript added anywhere in this round.

## 13. Confirmation

**No fabricated proof was added.** Every operational statement in the new sections describes process, ownership, or deliverables the site already documents. Where evidence does not yet exist, the site says so plainly and shows clearly-labelled illustrative material instead.
