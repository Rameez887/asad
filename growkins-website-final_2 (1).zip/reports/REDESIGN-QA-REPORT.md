# Visual Redesign — QA Report

**Scope:** site-wide visual-communication redesign (Belkins-level polish, 100% GROWKINS-unique). No copy, SEO, URL, navigation, schema, or functionality changes.

## Copy & SEO parity (automated)

- Visible text extracted from all 43 pages and diffed against the pre-redesign build: **identical everywhere**, with one intended exception — the homepage hero's old decorative infographic labels (inside an `aria-hidden` block) were replaced by the new illustrated scene, exactly as the brief requested.
- `<title>`, all `<meta>` tags, canonical links, and every JSON-LD block: **byte-for-byte identical** on all 43 pages.
- URLs, filenames, internal links: unchanged (5,552 relative references, 0 broken).

## What was added

- ~45 unique inline-SVG illustration scenes (page heroes for every service, industry, company, resource, legal page + homepage hero dashboard scene), all `aria-hidden`, built from one composable brand-palette system (navy/blue/violet/lime).
- Per-service illustration strips on the homepage service cards; illustrated thumbnails on insights cards; growth-motif decorations + background shapes on every CTA banner.
- Self-hosted Inter typeface (4 weights, woff2, `font-display:swap`) — no CDN dependency, no new third-party requests.
- Reveal-on-scroll + gentle float/pulse motion (`enhance.js` + CSS), fully gated on `prefers-reduced-motion`, with a 3.5s always-reveal safety net so content can never stay hidden.
- Refreshed design system in the shared stylesheet: lighter, airier sections, refined type scale, layered shadows, pill eyebrows, upgraded nav, cards, FAQ, timeline, comparison table, forms, footer.

## Browser sweep (headless Chromium)

All 43 pages × 4 viewports (360, 390, 768, 1280 px):

| Check | Result |
|---|---|
| Pages load (HTTP 200) | 172/172 PASS |
| JavaScript console/page errors | 0 (only the pre-existing, absent-favicon probe) |
| Horizontal overflow | 0 px everywhere — including two pre-existing mobile overflow bugs (Why GROWKINS, Our Process) now fixed |
| Inter font loads self-hosted | PASS |
| ROI calculator computes and updates | PASS |
| Mobile menu opens/closes | PASS |
| Dropdown navigation | PASS |
| Reveal animation + reduced-motion fallback + safety net | PASS |
| Metadata/schema parity | PASS (identical) |

## Accessibility & performance notes

- Every illustration is decorative and marked `aria-hidden="true"`; no information is conveyed by graphics alone — all original text remains in the DOM.
- Contrast-bearing text colors unchanged or darkened; semantic HTML untouched.
- Zero raster images added; everything is inline SVG. Fonts are the only new assets (~97 KB woff2 total, swap-rendered). No third-party requests were added (the Google Fonts approach was deliberately avoided).
- Animations run only under `prefers-reduced-motion: no-preference`.

## Known notes

- `source/revenue-growth-site.html` (the single-file SPA master) intentionally still reflects the pre-redesign visuals; its copy remains the valid text reference. `website/` is the canonical redesigned build.
- The favicon remains absent (pre-existing) — still flagged in the owner-action checklist.
