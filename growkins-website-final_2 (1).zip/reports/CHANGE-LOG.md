# GROWKINS Rebrand — File-by-File Change Log

Every change was a deterministic token substitution, verified by byte-level replay against the original files (0 unexpected differences across all 50 text files). Domain-based references (`leadsreps.com`, including `hello@leadsreps.com`) were deliberately preserved in every file pending owner confirmation — see OWNER-ACTION-CHECKLIST.md.

Replacement key: `LeadsReps`/`LEADSREPS` → `GROWKINS`; slugs `why-leadsreps` → `why-growkins`, `the-leadsreps-method` → `the-growkins-method`; asset `leadsreps-icp-worksheet.pdf` → `growkins-icp-worksheet.pdf`; JS constant `LEADSREPS_METHOD` → `GROWKINS_METHOD`.

---

File: source/revenue-growth-site.html
Old reference: why-leadsreps ×8; leadsreps-icp-worksheet ×1; LEADSREPS_METHOD ×3; LeadsReps ×252
New reference: GROWKINS; GROWKINS_METHOD; growkins-icp-worksheet; why-growkins
Type: Visible copy / metadata / schema / code (source master)
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (2)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/README.md
Old reference: why-leadsreps ×2; the-leadsreps-method ×1; LeadsReps ×21
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Documentation
Functionality affected: No
Owner confirmation required: No
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/index.html
Old reference: why-leadsreps ×4; the-leadsreps-method ×3; leadsreps-icp-worksheet ×2; LeadsReps ×23
New reference: GROWKINS; growkins-icp-worksheet; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (9)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/outbound-roi-calculator.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; leadsreps-icp-worksheet ×1; LeadsReps ×14
New reference: GROWKINS; growkins-icp-worksheet; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (7)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/robots.txt
Old reference: —
New reference: —
Type: Metadata
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (1)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/sitemap.xml
Old reference: why-leadsreps ×1; the-leadsreps-method ×1
New reference: the-growkins-method; why-growkins
Type: Metadata
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (43)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/industries/agency-lead-generation.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×26
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/industries/ai-lead-generation.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×26
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/industries/construction-lead-generation.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×26
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/industries/consulting-lead-generation.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×26
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/industries/cybersecurity-lead-generation.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×26
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/industries/financial-services-lead-generation.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×26
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/industries/fintech-lead-generation.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×26
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/industries/healthcare-lead-generation.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×26
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/industries/industries.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×13
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/industries/industry-it-services.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×13
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/industries/industry-professional-services.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×13
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/industries/logistics-lead-generation.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×26
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/industries/manufacturing-lead-generation.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×26
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/industries/media-production-lead-generation.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×26
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/industries/recruitment-lead-generation.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×26
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/industries/saas-lead-generation.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×26
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/industries/telecommunications-lead-generation.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×26
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/services/account-based-marketing.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×17
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (8)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/services/appointment-setting.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×17
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (8)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/services/cold-calling.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×17
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (8)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/services/email-outreach.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×17
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (8)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/services/lead-generation.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×17
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (8)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/services/linkedin-outreach.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×16
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (8)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/services/outbound-sales.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×17
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (8)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/services/sdr-as-a-service.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×17
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (8)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/services/services.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×16
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/legal/acceptable-use-policy.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×31
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/legal/accessibility-statement.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×24
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/legal/data-processing-agreement.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×41
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/legal/disclaimer.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×27
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/legal/privacy-policy.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×23
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/company/about.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×27
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/company/careers.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×17
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/company/contact.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×23
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (7)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/company/faq.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×29
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/company/how-we-work.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×17
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/company/partners.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×24
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/company/the-growkins-method.html  (renamed from website/company/the-leadsreps-method.html)
Old reference: why-leadsreps ×3; the-leadsreps-method ×6; LeadsReps ×23
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: Yes — page filename renamed; all internal links, sitemap entries, and SPA routes updated (verified, 0 broken refs)
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/company/why-growkins.html  (renamed from website/company/why-leadsreps.html)
Old reference: why-leadsreps ×6; the-leadsreps-method ×3; LeadsReps ×34
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: Yes — page filename renamed; all internal links, sitemap entries, and SPA routes updated (verified, 0 broken refs)
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/resources/insights.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; leadsreps-icp-worksheet ×1; LeadsReps ×15
New reference: GROWKINS; growkins-icp-worksheet; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (7)
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/resources/success-stories.html
Old reference: why-leadsreps ×3; the-leadsreps-method ×3; LeadsReps ×18
New reference: GROWKINS; the-growkins-method; why-growkins
Type: Visible copy / metadata / schema
Functionality affected: No
Owner confirmation required: Yes — file also contains preserved leadsreps.com domain/email references (6)
Notes: Marketing uses of the word "leads" left untouched.

---

File: documentation/Round-2-Visual-Change-Log-and-QA-Report.md
Old reference: LeadsReps ×9
New reference: GROWKINS
Type: Documentation
Functionality affected: No
Owner confirmation required: No
Notes: Marketing uses of the word "leads" left untouched.

---

File: website/assets/og-image.png
Old reference: Raster social-sharing image displaying "LeadsReps"
New reference: Regenerated 1200×630 image displaying "GROWKINS" — same navy background, blue logo mark, headline, and lime subtitle; same filename so no code references changed
Type: Asset
Functionality affected: No
Owner confirmation required: No
Notes: Same dimensions (1200×630) and visual identity; no new taglines or claims added.

---

File: website/assets/downloads/growkins-icp-worksheet.pdf  (renamed from website/assets/downloads/leadsreps-icp-worksheet.pdf)
Old reference: 6-page ICP worksheet with LEADSREPS header, LeadsReps body references, and LeadsReps PDF metadata
New reference: Regenerated 6-page PDF with GROWKINS branding; same ReportLab design (blue accents, numbered section chips, identical worksheet content); PDF Title/Author metadata updated
Type: Asset
Functionality affected: Yes — filename renamed; all 4 code references (2× index.html, 1× ROI calculator, 1× insights page, plus source master) updated and verified
Owner confirmation required: Yes — footer retains www.leadsreps.com/#contact and hello@leadsreps.com pending confirmed replacements
Notes: Content, structure, and page count unchanged; only brand references replaced.

---

File: documentation/GROWKINS-Website-Documentation.docx  (renamed from documentation/LeadsReps-Website-Documentation.docx)
Old reference: LeadsReps ×25 (paragraphs, tables, metadata)
New reference: GROWKINS
Type: Documentation
Functionality affected: No
Owner confirmation required: No
Notes: Content otherwise unchanged.

---

File: documentation/GROWKINS-WordPress-Developer-Instructions.docx  (renamed from documentation/LeadsReps-WordPress-Developer-Instructions.docx)
Old reference: LeadsReps ×9 (headings, paragraphs)
New reference: GROWKINS
Type: Documentation
Functionality affected: No
Owner confirmation required: No
Notes: New Section 17 added — "GROWKINS Rebrand — WordPress Migration Checklist" (22 items). The section intro intentionally names the old brand once to explain the rename to the WordPress developer.

---
