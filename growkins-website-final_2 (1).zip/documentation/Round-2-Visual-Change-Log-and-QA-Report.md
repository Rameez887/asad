# GROWKINS Website — Round 2 Visual Change Log & QA Report
## Infographic and Visual Enhancement Pass

This document covers only Round 2 (this round). Round 1 (emoji→SVG icon replacement + homepage hero infographic) is documented separately in `website/README.md` under "Emoji-to-SVG icon system and homepage hero infographic (round 26)".

Scope confirmed for every item below: no copy, heading, CTA wording, navigation, footer, page structure, URL, SEO title/meta/schema, form, pricing, color, font, or functional JavaScript was changed. The only new visible text anywhere is the diagram/group label text listed in each entry, and every one of those labels is copied from content that already existed elsewhere on that same page.

---

## 1. Visual Change Log

### Homepage — "Sound familiar?" challenge section
- **Original state:** A flat 8-item grid of challenge statements, no grouping.
- **Visual update:** The same 8 statements are now organized into 3 labeled theme columns (Targeting Problems, Execution Problems, Visibility Problems) with a small icon heading per column.
- **Files changed:** `source/revenue-growth-site.html` (`HOME_CHALLENGE_GROUPS`, `pageHome()`, `.problem-map` CSS)
- **Responsive behaviour:** 3 columns ≥820px; collapses to a single column below 820px. No horizontal overflow at 320–1920px.
- **Accessibility treatment:** Column icons are `aria-hidden="true"`; all 8 challenge statements remain real, visible text (unchanged).
- **Copy changed:** No
- **Functional behaviour changed:** No

### Homepage — "What we do for your pipeline" services section
- **Original state:** Section opened directly into the services grid.
- **Visual update:** A `miniFlow` diagram (ICP & Targeting → Lead Research → Multi-Channel Outreach → Qualification → Meeting Booking outcome) was added above the existing services grid.
- **Files changed:** `source/revenue-growth-site.html` (`HOME_SYSTEM_FLOW`, `HOME_SYSTEM_OUTCOME`, `miniFlow()`, `pageHome()`)
- **Responsive behaviour:** Horizontal row ≥760px; collapses to a vertical stack with downward arrows below 760px. No overflow at any tested width.
- **Accessibility treatment:** Diagram container has `role="img"` and a full descriptive `aria-label`; individual step icons are `aria-hidden="true"`.
- **Copy changed:** No
- **Functional behaviour changed:** No

### Homepage — ROI calculator section
- **Original state:** Calculator form only, single column.
- **Visual update:** Restructured into a two-column layout — the existing calculator is unchanged on one side; a new `miniFlow` diagram (Current Pipeline Inputs → Outbound Capacity → Opportunity Potential → Revenue Scenario outcome) sits beside it.
- **Files changed:** `source/revenue-growth-site.html` (`CALC_FLOW`, `CALC_OUTCOME`, `.calc-with-visual`, `.calc-visual-panel`)
- **Responsive behaviour:** Two columns ≥820px; stacks to one column below 820px, calculator first. Calculator functionality untouched and unaffected at any width.
- **Accessibility treatment:** Diagram has `role="img"` + `aria-label`; calculator form fields, labels, and live-region outputs are all unchanged.
- **Copy changed:** No
- **Functional behaviour changed:** No (ROI calculator math/JS untouched)

### Homepage — "Built for quality, engineered to scale" section
- **Original state:** Section opened directly into a 3-card grid.
- **Visual update:** A `miniFlow` diagram (ICP Definition → Verified Data → Message Personalisation → Human Qualification → Reporting & Optimisation outcome) was added above the existing 3-card grid.
- **Files changed:** `source/revenue-growth-site.html` (`QUALITY_FLOW`, `QUALITY_OUTCOME`, `pageHome()`)
- **Responsive behaviour:** Same collapse behaviour as the other `miniFlow` instances (vertical stack below 760px).
- **Accessibility treatment:** Same `role="img"` / `aria-hidden` pattern as above.
- **Copy changed:** No
- **Functional behaviour changed:** No

### Homepage — closing CTA band
- **Original state:** Title, subtitle, two buttons — no visual motif.
- **Visual update:** Added an optional small decorative icon row (target → arrow → calendar) above the CTA text, used only on this one CTA band sitewide.
- **Files changed:** `source/revenue-growth-site.html` (`ctaBanner()` 7th `motif` param, `.cta-motif` CSS)
- **Responsive behaviour:** Scales down proportionally; no layout shift at any width.
- **Accessibility treatment:** `aria-hidden="true"` (purely decorative, adds no information).
- **Copy changed:** No
- **Functional behaviour changed:** No

### Service Hub (`/services/`) — service grid
- **Original state:** Eyebrow/heading followed directly by the 8-service grid.
- **Visual update:** A new "Outbound System" diagram was added above the grid, grouping the same 8 real service titles into 4 labeled stages (Foundation, Outreach, Conversion, Growth System).
- **Files changed:** `source/revenue-growth-site.html` (`SERVICE_SYSTEM_GROUPS`, `outboundSystemDiagram()`, `.outbound-system` CSS)
- **Responsive behaviour:** Row of 4 cards ≥900px; stacks vertically below 900px with arrows rotated downward.
- **Accessibility treatment:** `role="img"` + full descriptive `aria-label`; icons `aria-hidden="true"`.
- **Copy changed:** No
- **Functional behaviour changed:** No

### All 8 individual Service pages — workflow diagram
*(Appointment Setting, Lead Generation, SDR as a Service, Outbound Sales, Email Outreach, Cold Calling, LinkedIn Outreach, Account-Based Marketing)*
- **Original state:** "What is [service]?" explainer paragraph(s), then directly into "Common Challenges."
- **Visual update:** One `miniFlow` workflow diagram was added immediately after the explainer and before "Common Challenges," showing that service's real step sequence (e.g. Appointment Setting: Target Prospect → Outreach → Conversation → Qualification → Calendar Booking outcome).
- **Files changed:** `source/revenue-growth-site.html` (`SERVICE_FLOWS`, `serviceFlowDiagram()`, one call site added per service page function)
- **Responsive behaviour:** Same `miniFlow` collapse pattern (vertical stack below 760px) on all 8 pages.
- **Accessibility treatment:** `role="img"` + `aria-label` per diagram; icons `aria-hidden="true"`.
- **Copy changed:** No
- **Functional behaviour changed:** No

### All 14 Industry pages — target-market diagram
*(SaaS, AI, Cybersecurity, Agencies, Construction, Consulting, Financial Services, FinTech, Healthcare, Logistics, Manufacturing, Media Production, Recruitment, Telecommunications)*
- **Original state:** Segment pill-row (existing) followed directly by the "Common Challenges" section.
- **Visual update:** A 4-node funnel diagram (Industry → Ideal Accounts → Decision-Makers → Qualified Opportunities) was added after the segment pill-row. Account and decision-maker pill labels are pulled directly from that industry's own existing `segments`/`stakeholders` data (first 4 of each) — no new categories were invented for any industry.
- **Files changed:** `source/revenue-growth-site.html` (`industryTargetDiagram()`, `.target-diagram` CSS, one call site in `pageIndustryLG()` shared by all 14 industries)
- **Responsive behaviour:** Row of 4 cards ≥960px; stacks vertically below 960px with arrows rotated downward. Verified individually on 5 representative industries (SaaS, AI, Cybersecurity, Construction, Recruitment) plus a full 14-industry data-completeness check.
- **Accessibility treatment:** `role="img"` + per-industry descriptive `aria-label` (names the specific accounts/decision-makers shown); icons `aria-hidden="true"`.
- **Copy changed:** No
- **Functional behaviour changed:** No

### About page — team section
- **Original state:** Intro paragraph + 7-card team-role grid (Revenue Strategist, Account Manager, Prospect Research Specialist, Campaign Copywriter, SDR, Deliverability Specialist, Revenue Operations Analyst).
- **Visual update:** Added a "How GROWKINS fits into your sales team" diagram below the existing grid, showing 4 of the real team roles feeding into "Your Sales Team" (Account Executives) and a "Qualified Meetings & Pipeline" outcome node.
- **Files changed:** `source/revenue-growth-site.html` (`aboutFitDiagram()`, `pageAbout()`)
- **Responsive behaviour:** 3-card row ≥960px; stacks vertically below 960px. No overflow at 320–1920px.
- **Accessibility treatment:** `role="img"` + `aria-label`; icons `aria-hidden="true"`.
- **Copy changed:** No
- **Functional behaviour changed:** No

### The GROWKINS Method page
- **Original state:** 13 numbered steps in a single flat sequence.
- **Visual update:** The same 13 steps are now visually grouped into 4 labeled phases (Foundation, Messaging & Launch, Conversion, Optimise) via a small kicker/divider heading placed before the first step of each phase.
- **Files changed:** `source/revenue-growth-site.html` (`METHOD_PHASE_GROUPS`, `.method-phase-head` CSS, `pageMethodology()`)
- **Responsive behaviour:** Divider headings inherit the existing step-list's responsive behaviour (already verified single-column on mobile).
- **Accessibility treatment:** Phase dividers are real heading text (not decorative), read naturally by screen readers in document order.
- **Copy changed:** No (13 step titles/descriptions unrenumbered and unchanged)
- **Functional behaviour changed:** No

### Contact page — "What Happens Next"
- **Original state:** 5-step text list, no icons.
- **Visual update:** Each of the 5 existing steps now shows a small icon beside its title, matching the icon-and-label pattern already used on the Our Process page.
- **Files changed:** `source/revenue-growth-site.html` (`CONTACT_STEPS` extended with an icon reference per step, `.step-head`/`.step-icon` render)
- **Responsive behaviour:** Unchanged layout, icons scale with existing step-card responsive rules.
- **Accessibility treatment:** Icons `aria-hidden="true"`; step titles/descriptions remain the accessible content.
- **Copy changed:** No
- **Functional behaviour changed:** No

### Why GROWKINS page & all 14 Industry pages — comparison table
- **Original state:** A `<table class="compare">` that required horizontal scrolling on narrow phones to read which column ("Typical Agency" vs. "GROWKINS") a value belonged to.
- **Visual update:** Below 640px, the table converts to a stacked card layout; each value now carries a small, real (non-CSS-generated) label naming its column, always visible.
- **Files changed:** `source/revenue-growth-site.html` (`.compare-mobile-label` + `@media(max-width:640px)` table-to-card CSS block; `<td>` markup updated at both table render call sites)
- **Responsive behaviour:** Table renders normally ≥640px (unchanged); stacked labeled cards below 640px. Verified via direct desktop/mobile screenshot comparison.
- **Accessibility treatment:** Column identity is now conveyed through real visible text at every width, not through table headers that scroll out of view or through color alone.
- **Copy changed:** No (row content unchanged, only the column-identifying label is new and matches the existing table header text)
- **Functional behaviour changed:** No

---

## 2. File-by-File Change List

| File | Change |
|---|---|
| `source/revenue-growth-site.html` | All Round 2 additions described above: new data objects (`SERVICE_FLOWS`, `HOME_CHALLENGE_GROUPS`, `SERVICE_SYSTEM_GROUPS`, `METHOD_PHASE_GROUPS`), new reusable functions (`miniFlow()`, `serviceFlowDiagram()`, `outboundSystemDiagram()`, `industryTargetDiagram()`, `aboutFitDiagram()`), new CSS for all of the above, and one call-site injection per page listed in Section 1. No other lines changed. |
| `website/**/*.html` (all 43 static pages) | Regenerated from the updated source via `export.mjs` — reflects the same Round 2 changes, no independent edits. |
| `website/README.md` | Two new changelog entries added at the top (round 26 recap for Round 1, round 27 for this round) plus two new "Before launch" items disclosing pre-existing issues found during this round's QA (unrelated JS syntax issue, pre-existing overflow cases). |
| `documentation/GROWKINS-WordPress-Developer-Instructions.docx` | Extended with Sections 10–16: the two new diagram patterns, the 15 named reusable WordPress blocks, SVG handling/sanitization standards, global theme.json design tokens, suggested ACF field schemas, and a Round 2 responsive/performance/SEO/forms/accessibility/editing-experience checklist. Sections 1–9 (Round 1 content) are unchanged. |
| `export.mjs`, `verify_dist.mjs`, `linkcheck.mjs` | Unchanged — re-run against the updated source, not modified. |

---

## 3. Responsive QA Report

**Method:** Full Playwright sweep of all 43 SPA routes at 9 breakpoints (320, 360, 390, 430, 768, 1024, 1280, 1440, 1920px), checking `document.documentElement.scrollWidth - clientWidth` for horizontal overflow, plus targeted element screenshots of every new diagram at desktop and mobile widths.

**Result:** Zero JavaScript console/page errors across all 43 routes × 9 breakpoints (387 checks). 11 horizontal-overflow instances were found; all 11 were independently confirmed present in the pre-Round-1 backup (`revenue-growth-site.BACKUP.html`) at matching or near-matching pixel amounts, and are therefore pre-existing, not introduced by Round 1 or Round 2:

| Page | Widths affected | Overflow amount | Pre-existing? |
|---|---|---|---|
| Why GROWKINS | 320 / 360 / 390 / 430px | 140 / 100 / 70 / 30px | Confirmed in backup (identical) |
| Our Process | 320 / 360 / 390 / 430px | 281 / 241 / 211 / 171px | Confirmed in backup (277px at 320px — 4px difference attributable to Round 1's icon additions, not Round 2) |
| Telecommunications (industry) | 320 / 360px | 54 / 14px | Confirmed in backup (identical) |
| Media Production (industry) | 320px | 3px | Confirmed in backup (identical) |

Root cause identified for the Why GROWKINS / Our Process cases: a pre-existing `.step` grid layout with fixed-width cards that doesn't collapse to single-column below ~440px. Root cause for the two industry pages: long unbroken segment/service names in a pill-row. Neither is related to any Round 1 or Round 2 visual work — both predate this project's icon/infographic passes and are flagged in `website/README.md`'s "Before launch" list rather than fixed here, per the "don't change anything else" scope constraint.

All new Round 2 components (8 service workflow diagrams, 14 industry target diagrams, the Service Hub outbound-system diagram, and the About page team-fit diagram) introduced **zero** new overflow at any tested width. The industry target-diagram's node width was tuned specifically during this round's QA (from 210px to 188px per node) after an initial version wrapped awkwardly inside the page's 880px content column.

---

## 4. Accessibility Review Summary

- Every new diagram container carries `role="img"` and a complete, human-readable `aria-label` describing what the diagram shows (e.g. "Diagram: SaaS accounts such as B2B Software, Sales Technology... lead to decision-makers including CEOs, Founders..., resulting in qualified opportunities").
- Every icon inside a new diagram is `aria-hidden="true"` — the container's `aria-label` carries the meaning, individual icons are purely decorative reinforcement of the adjacent visible label.
- No new diagram conveys information through color alone: the "outcome" node in every diagram is distinguished by position (always last), a filled background, and different copy ("Qualified Opportunities," "Meeting," etc.), not by color alone.
- The comparison-table mobile conversion uses real, visible HTML text for its column labels (a `<span>`, not CSS `::before`/`::after` generated content), so the labeling survives custom user stylesheets, some assistive-technology configurations, and print/reader-mode views that strip generated content.
- No autoplay, flashing, or motion was introduced; the one CSS transition in the new components (a subtle collapse to vertical layout via media query, not an animation) does not need a `prefers-reduced-motion` guard since it is a layout breakpoint, not a played animation.
- Manual spot-check via Playwright confirmed no new diagram breaks tab order or introduces a keyboard trap — none of the new elements are interactive (no links/buttons inside any diagram), so no new focus-management concerns were introduced.

---

## 5. Performance Impact Summary

- No new JavaScript framework, animation library, icon font, or external dependency was added. Every new component is static HTML generated at page-render time by the existing template-literal page functions, styled with plain CSS already living in the single `<style>` block.
- Every new icon reuses the existing inline-SVG pattern (`MF_ICON` object) — zero new image requests, zero new font requests.
- Total added markup per page is small: one diagram (typically 4–5 icon+label nodes) per page that has one, consistent with the spec's "max one major infographic per section" density rule. No page received more than one new major diagram in Round 2's homepage sections, and homepage/service-hub/about received a small number of proportionate additions consistent with their existing depth.
- `export.mjs`'s static-export pipeline required no changes — the new components render as plain HTML in the Playwright-rendered snapshot exactly like existing content, so no build-step or bundling changes were needed.
- No measurable render-blocking resources were added; all 43 static pages re-exported successfully with the same CSS/JS asset footprint as before this round (`assets/css/style.css`, `assets/js/nav.js` unchanged in size/structure beyond the new CSS rules already accounted for above).

---

## 6. Verification Performed

- `node --check` syntax validation of the extracted `<script>` block after every edit — passed throughout.
- Full data-completeness check confirming all 14 `INDUSTRY_LG` entries have non-empty `segments` and `stakeholders` arrays before building the target diagram against them.
- Playwright render + zero-console-error check for all 8 service pages, all 14 industry pages, the Service Hub, About, Methodology, Contact, and Why GROWKINS pages individually, plus the full 43-route sweep described in Section 3.
- Word-level text-parity diff of every one of the 43 routes' rendered visible text against the pre-Round-1 backup, confirming: (a) all "added" text is exactly the new diagram/group labels documented in Section 1, and (b) all "removed" text is exactly the Round 1 emoji characters already disclosed and verified in that round — no unintended copy loss anywhere.
- `node export.mjs` re-run: 43/43 static pages exported successfully.
- `node verify_dist.mjs`: all 43 static pages pass.
- `node linkcheck.mjs`: 5,552 relative references checked across 43 files, 0 broken.
