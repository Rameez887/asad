/* GROWKINS visual enhancement layer — progressive, non-functional.
   Adds reveal-on-scroll classes. No content, navigation, or form behaviour is touched. */
(function () {
  if (!('IntersectionObserver' in window)) return;
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduce) return;

  var selectors = [
    '.sec-head', '.card', '.deliver', '.quote-card', '.case-card', '.post-card',
    '.step', '.phase', '.result-tile', '.qa-block', '.duo .d-card',
    '.os-group', '.td-node', '.rma-row', '.cta-banner', '.form-card',
    '.flow-h-item', '.mini-flow', '.compare', '.check-list', '.pill-row'
  ];
  var els = document.querySelectorAll(selectors.join(','));
  var groupIndex = {};
  els.forEach ? null : (els = Array.prototype.slice.call(els));
  Array.prototype.forEach.call(els, function (el) {
    el.classList.add('rv');
    var parent = el.parentElement;
    if (parent) {
      var key = parent.className || 'root';
      groupIndex[key] = (groupIndex[key] || 0) + 1;
      var i = (groupIndex[key] - 1) % 4;
      if (i === 1) el.classList.add('rv-d1');
      else if (i === 2) el.classList.add('rv-d2');
      else if (i === 3) el.classList.add('rv-d3');
    }
  });

  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (e.isIntersecting) {
        e.target.classList.add('in-view');
        io.unobserve(e.target);
      }
    });
  }, { rootMargin: '0px 0px -4% 0px', threshold: 0.01 });

  Array.prototype.forEach.call(document.querySelectorAll('.rv'), function (el) {
    // Elements already in the viewport reveal immediately (no first-paint flash).
    var r = el.getBoundingClientRect();
    if (r.top < window.innerHeight && r.bottom > 0) {
      el.classList.add('in-view');
    } else {
      io.observe(el);
    }
  });

  // Safety net: never leave content hidden (slow devices, odd scroll patterns).
  setTimeout(function () {
    Array.prototype.forEach.call(document.querySelectorAll('.rv:not(.in-view)'), function (el) {
      el.classList.add('in-view');
    });
  }, 3500);
})();
