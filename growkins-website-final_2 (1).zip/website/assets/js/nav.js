function toggleMenu(){ document.getElementById('mobileMenu').classList.toggle('open'); }

function switchCalcTab(tab){
  const tabRoi = document.getElementById('calc-tab-roi'), tabCost = document.getElementById('calc-tab-cost');
  const panelRoi = document.getElementById('calc-panel-roi'), panelCost = document.getElementById('calc-panel-cost');
  if(!tabRoi || !tabCost || !panelRoi || !panelCost) return;
  tabRoi.classList.toggle('active', tab === 'roi');
  tabCost.classList.toggle('active', tab === 'cost');
  panelRoi.classList.toggle('active', tab === 'roi');
  panelCost.classList.toggle('active', tab === 'cost');
}

function calcROI(){
  const el = id => document.getElementById(id);
  if(!el('roi-volume')) return;
  const num = id => parseFloat(el(id).value) || 0;
  const volume = num('roi-volume');
  const response = num('roi-response') / 100;
  const meetingRate = num('roi-meeting') / 100;
  const oppRate = num('roi-opp') / 100;
  const closeRate = num('roi-close') / 100;
  const dealValue = num('roi-deal');
  const cost = num('roi-cost');

  const responses = volume * response;
  const meetings = responses * meetingRate;
  const opps = meetings * oppRate;
  const customers = opps * closeRate;
  const revenue = customers * dealValue;
  const profit = revenue - cost;
  const roi = cost > 0 ? (profit / cost) * 100 : 0;
  const cpm = cost / meetings;
  const cpo = cost / opps;
  const cac = cost / customers;

  const fmt = n => Math.round(n).toLocaleString();
  const fmtMoney0 = n => '$' + Math.round(n).toLocaleString();
  const fmtMoney2 = n => isFinite(n) ? '$' + n.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2}) : '—';

  el('out-responses').textContent = fmt(responses);
  el('out-meetings').textContent = fmt(meetings);
  el('out-opps').textContent = fmt(opps);
  el('out-customers').textContent = customers.toFixed(1);
  el('out-revenue').textContent = fmtMoney0(revenue);
  el('out-profit').textContent = fmtMoney0(profit);
  el('out-roi').textContent = isFinite(roi) ? Math.round(roi) + '%' : '—';
  el('out-cpm').textContent = fmtMoney2(cpm);
  el('out-cpo').textContent = fmtMoney2(cpo);
  el('out-cac').textContent = fmtMoney2(cac);
}

function calcCost(){
  const el = id => document.getElementById(id);
  if(!el('cost-volume')) return;
  const volume = parseFloat(el('cost-volume').value) || 0;
  const channels = ['cost-ch-email','cost-ch-linkedin','cost-ch-calling'].filter(id => el(id).checked).length || 1;
  const markets = parseFloat(el('cost-markets').value) || 1;
  const reps = parseFloat(el('cost-reps').value) || 1;
  const appt = el('cost-appt').value === 'yes';
  const dataSourcing = el('cost-data').value === 'yes';
  const crm = el('cost-crm').value === 'yes';
  const reporting = el('cost-reporting').value;

  let base;
  if(volume <= 3000) base = 2500;
  else if(volume <= 8000) base = 3500;
  else if(volume <= 15000) base = 5000;
  else base = 6500;

  let addon = 0;
  addon += Math.max(0, channels - 1) * 300;
  addon += Math.max(0, markets - 1) * 250;
  addon += Math.max(0, reps - 1) * 200;
  if(appt) addon += 500;
  if(dataSourcing) addon += 400;
  if(crm) addon += 300;
  if(reporting === 'advanced') addon += 300;

  const total = base + addon;
  const low = Math.round((total * 0.9) / 100) * 100;
  const high = Math.round((total * 1.15) / 100) * 100;

  el('out-costrange').textContent = '$' + low.toLocaleString() + '–$' + high.toLocaleString();

  const included = ['targeting & ICP definition','list building & verification','outreach copywriting','campaign management','multi-channel outreach'];
  if(appt) included.push('appointment setting');
  if(dataSourcing) included.push('data sourcing');
  if(crm) included.push('CRM management');
  included.push(reporting === 'advanced' ? 'advanced reporting & optimization' : 'standard reporting');
  el('out-costdesc').textContent = 'Your campaign could include: ' + included.join(', ') + '.';
}

function calcMiniROI(){
  const el = id => document.getElementById(id);
  if(!el('mini-volume')) return;
  const volume = parseFloat(el('mini-volume').value) || 0;
  const dealValue = parseFloat(el('mini-deal').value) || 0;
  const responses = volume * 0.03;
  const meetings = responses * 0.30;
  const opps = meetings * 0.40;
  const customers = opps * 0.20;
  const revenue = customers * dealValue;
  el('mini-out-meetings').textContent = Math.round(meetings).toLocaleString();
  el('mini-out-customers').textContent = customers.toFixed(1);
  el('mini-out-revenue').textContent = '$' + Math.round(revenue).toLocaleString();
}

document.addEventListener('DOMContentLoaded', function(){
  if(document.getElementById('roi-volume')){ calcROI(); calcCost(); }
  if(document.getElementById('mini-volume')) calcMiniROI();
});