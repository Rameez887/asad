# GROWKINS Website — Production-Ready Static Export

43 static HTML pages, buyer-focused lead-generation positioning, full per-page SEO, shared assets, plus a real downloadable resource and an interactive ROI calculator. Crawlable without JavaScript except for the calculator itself, which needs it to compute. Upload to any static host — no build step.

## Belkins-level visual redesign (this round)

A site-wide visual-communication redesign — copy, headlines, SEO metadata, schema, URLs, navigation, forms, and calculator logic are byte-for-byte unchanged (verified by automated text/metadata parity against the pre-redesign build; the only visible-text delta is the old homepage hero infographic's decorative labels, replaced by an illustrated scene).

What changed, all layered on the existing markup:

1. **Design system refresh (`assets/css/style.css`)** — light, airy, premium: self-hosted Inter type (400/600/700/800 in `assets/fonts/`, `font-display:swap`, no third-party requests), larger section rhythm and whitespace, refined layered shadows and radii, pill eyebrows, gradient logo mark, upgraded nav/dropdowns/buttons/cards/FAQ/timeline/footer, dot-grid + glow treatments on dark bands. All pre-existing class names keep working.
2. **Custom SVG illustration system (~45 unique scenes)** — every page hero (homepage + all 42 inner pages) now carries a hand-composed, brand-palette inline-SVG scene (dashboards, funnels, calendars, node graphs, buyer journeys, comparison panels…), unique per service/industry/company page, `aria-hidden` so accessibility and SEO text are untouched. Homepage service cards get per-service illustration strips; insights post cards get illustrated thumbnails; every CTA banner gets background shapes + a growth-chart motif.
3. **Motion layer (`assets/js/enhance.js`)** — reveal-on-scroll and gentle floating/pulse accents, fully respecting `prefers-reduced-motion`, with an always-reveal safety net. No functional JS touched.
4. **Responsive/QA** — all 43 pages swept at 360/390/768/1280px: zero horizontal overflow (including two pre-existing overflow bugs on Why GROWKINS and Our Process, now fixed via responsive grid overrides), zero console errors, calculator/mobile menu/dropdowns verified, 5,552 internal references still intact.

## Company rename to GROWKINS (earlier round)

The public-facing company name changed from LeadsReps to **GROWKINS** (always uppercase in visible branding). This was a controlled name update only — no copy rewrite, design, structure, or functionality changes. Scope: visible copy, text logo, titles/metadata, Open Graph/Twitter tags, JSON-LD schema, accessibility labels, the Open Graph image (regenerated in the same design), the ICP worksheet PDF (regenerated in the same design as `assets/downloads/growkins-icp-worksheet.pdf`), and two brand-carrying page slugs (`company/why-leadsreps.html` → `company/why-growkins.html`, `company/the-leadsreps-method.html` → `company/the-growkins-method.html`) with every internal link and sitemap entry updated. Marketing uses of the word "leads" (qualified leads, lead generation, etc.) were deliberately left untouched. The confirmed domain (`www.growkins.com`) and business email (`info@growkins.com`) are now applied across all canonicals, Open Graph/Twitter URLs, JSON-LD, sitemap.xml, robots.txt, the contact page, and the ICP worksheet PDF. If the old URLs were ever live, add 301 redirects for the two renamed slugs.

## Infographic and Visual Enhancement Pass — refine and extend the existing icon/diagram system (round 27)

A follow-up visual pass, scoped strictly to the site's existing icon and infographic language: no copy, navigation, pricing, forms, or functional JavaScript changed anywhere. Everything added reuses the shared `MF_ICON` inline-SVG set and two new reusable rendering helpers, and every data-driven label traces back to content that already existed on that page — no invented personas, numbers, or comparison categories.

1. **New reusable components:** `miniFlow(steps, opts)` renders a horizontal/vertical step-flow with an optional highlighted outcome node (light or dark theme); it collapses to a vertical stack with downward arrows below 760px. A second helper, the target-diagram pattern (`.target-diagram`/`.td-node`), renders a 3–4 node funnel with grouped pill tags inside each node, collapsing to a vertical stack below 960px.
2. **Homepage:** the "Sound familiar?" challenge grid is now grouped into three labeled themes (Targeting Problems, Execution Problems, Visibility Problems) instead of one flat 8-item grid — same eight challenge statements, just organized. A `miniFlow` diagram was added above the services grid (ICP & Targeting → Lead Research → Multi-Channel Outreach → Qualification → Meeting Booking), above the "Built for quality" cards (ICP Definition → Verified Data → Personalisation → Human Qualification → Reporting), and beside the ROI calculator (Pipeline Inputs → Outbound Capacity → Opportunity Potential → Revenue Scenario). The closing CTA band gained a small decorative icon motif.
3. **Service Hub (`/services/`):** a new "Outbound System" diagram groups the eight real services into four labeled stages — Foundation, Outreach, Conversion, Growth System — using each service's existing title, placed above the existing service grid.
4. **All 8 individual service pages** now include one reusable workflow diagram each, placed right after the page's own "What is [service]?" explainer and before "Common Challenges." Each diagram's steps describe how that service already runs per its own page copy (e.g. Appointment Setting: Target Prospect → Outreach → Conversation → Qualification → Calendar Booking).
5. **All 14 Industry pages** gained one target-market diagram (Industry → Ideal Accounts → Decision-Makers → Qualified Opportunities), placed after the existing segments list. Account and decision-maker labels are pulled directly from that industry's own `segments`/`stakeholders` data — no new categories were invented for any industry.
6. **About page:** a new "How GROWKINS fits into your sales team" diagram was added to the existing team section, showing the four already-listed team roles connecting to "Your Sales Team" and a "Qualified Meetings & Pipeline" outcome node.
7. **The GROWKINS Method:** the 13 existing steps are now visually grouped into four labeled phases (Foundation, Messaging & Launch, Conversion, Optimise) with a small divider heading before each phase's first step — the 13 steps themselves are unchanged and unrenumbered.
8. **Contact page:** the existing 5-step "What Happens Next" list now shows an icon beside each step, matching the icon-step pattern already used on the Our Process page.
9. **Comparison tables** (Why GROWKINS vs. typical agency; Industry pages' agency comparison) now convert to a labeled card layout below 640px instead of a horizontal-scrolling table — each row's value now carries a real, visible (not CSS-generated) label identifying which column it belongs to, so nothing depends on horizontal scrolling or color alone to be readable on a phone.
10. **Deliberately not touched this round**, per the visual density rule (roughly 60–70% of the site stays visually plain by design): the Resources page's guide/template cards, the FAQ page accordion styling, the Success Stories placeholder page, and the Industries Hub overview page were left as-is rather than adding a diagram to every remaining page — none of them needed a new visual to explain content that wasn't already clear as plain text.

Verified this round with: a `node --check` syntax pass, a Playwright sweep of all 43 SPA routes at 9 breakpoints (320–1920px) with zero console/page errors and zero new horizontal-overflow regressions (a handful of pre-existing overflow cases on the Why GROWKINS, Our Process, Telecommunications, and Media Production pages were confirmed present in the pre-Round-A backup and are unrelated to this round's changes — see the QA report), a full re-export and re-verification of all 43 static `dist/` pages, a link-check across all 43 static pages (5,552 relative references, zero broken), and a word-level text-parity diff of every route against the pre-Round-A backup confirming the only additions are the new diagram/label text listed above.

## Emoji-to-SVG icon system and homepage hero infographic (round 26)

Every decorative emoji sitewide (32 distinct icons across the homepage, process flow, and service/industry pages) was replaced with a matching inline SVG icon drawn in one consistent style (`viewBox="0 0 24 24"`, `stroke="currentColor"`, ~1.8px stroke, rounded caps/joins) — no emoji, 3D icons, or stock illustrations remain. The homepage hero gained a two-column infographic (five outreach channels converging on a "Qualified Sales Opportunities" outcome), and the existing outbound-process section's steps were given matching icons. No copy, layout, navigation, or functional JavaScript changed. A pre-existing, unrelated JavaScript syntax issue in two form handlers (Insights newsletter signup, Contact demo form) was found during verification and left untouched, since it predates this round's changes and fixing it wasn't in scope — see the QA report for details.

## Homepage hero rewritten for headline/subheadline consistency (round 25)

The hero headline changed from "Turn Target Accounts Into Qualified Sales Opportunities" to **"Scale Your Pipeline with Qualified Sales Opportunities."** The subheadline was rewritten to match: "We help B2B companies generate qualified sales opportunities through cold email, cold calling, LinkedIn outreach, appointment setting, and dedicated SDR teams." The reasoning: the previous subheadline described the services as building "predictable pipelines" while the headline promised "qualified sales opportunities" — two different outcome phrases for the same thing. The new subheadline echoes the headline's own language instead. Primary CTA ("Book a Strategy Call") and secondary CTA ("Explore Our Services") are unchanged. The homepage OG share-image generator in `export.mjs` was updated to match, so the social-preview image and the live page never drift apart again.

## Consistency pass from a deep competitive audit (round 24)

Five fixes from a detailed audit, all copy/consistency work — no new claims, no fabricated proof, nothing RevenueOS™-related reintroduced.

1. **Service cards are now outcome-first.** Every entry in the shared services array (used on the homepage grid, industry pages, and elsewhere) had its one-line pitch tightened to lead with the outcome rather than the activity — e.g. Cold Calling now reads "Turn conversations into qualified meetings with trained outbound callers" instead of a feature-first description. This cascades automatically everywhere the array is used.
2. **The GROWKINS Method's 13 step titles are now outcome-oriented** (e.g. "Prospect List Building" → "Build a Verified Prospect List That Matches Your ICP"), matching the audit's specific suggestion. Step descriptions are unchanged.
3. **All 8 service pages now follow byte-for-byte the same section structure and order.** Three pages (Lead Generation, Appointment Setting, SDR as a Service) had drifted from the canonical order established for the other five — their "Industries We Serve" and "Why Choose GROWKINS?" sections were in reverse order, and two used slightly different heading text ("Industries We Support," "Why Companies Choose GROWKINS"). All three were brought in line with the dominant pattern (What's Included → Why Choose GROWKINS? → Industries We Serve → FAQ → CTA), including matching CSS striping.
4. **One consistent primary CTA site-wide: "Book a Strategy Call."** Previously the site used two full variants ("Book a Strategy Call" and "Book Your Free Strategy Call," 7 vs. 13 occurrences) plus a handful of one-off phrasings ("Book a Free Strategy Call," "Book Your Free Revenue Strategy Call," a contextual industries-page label). All were standardized to "Book a Strategy Call," except the Contact page's own form-submit button, which intentionally keeps first-person phrasing ("Book My Strategy Call") as a distinct, deliberate UX choice for a final commit action rather than a navigational prompt.
5. **The "Why GROWKINS" page's route and filename now match the brand.** The route (`why-meridian` → `why-growkins`) and static filename (`why-meridian.html` → `why-growkins.html`) were renamed for URL/SEO consistency — this was leftover from the pre-rebrand "Meridian" name. All navigation links, the comparison-table "See the Full Comparison" button, and the internal PAGES registration were updated to match; nothing on the page's content changed.

Not done, and flagged instead as larger, more open-ended scope: a site-wide "Related Services / Related Industries / Related Resources" cross-linking block on every page, standardizing every industry page to a fixed pain-points/triggers/decision-makers/channels/FAQ/CTA structure, and a "Preferred Contact Method" field on the Contact form. These are reasonable ideas but touch many pages each with real design decisions (what to show on pages where "related content" doesn't obviously apply, e.g. legal pages) — worth a deliberate scoping conversation rather than a silent, inconsistent rollout.

## "The GROWKINS Method" — a new, distinct 13-step methodology page (round 23)

A new Company page was built at `company/the-growkins-method.html` (route `methodology`), added to the header dropdown, footer, and mobile menu right after "Our Process." It's deliberately distinct from Our Process rather than a duplicate: Our Process gives a 7-stage overview; The GROWKINS Method gives a granular 13-step breakdown for buyers doing diligence, with six steps linking straight through to their full service pages. Every step describes a real, already-established capability — no new claims were introduced.

## "RevenueOS™" retired site-wide (round 22)

All 15 remaining mentions of the "RevenueOS™" branded methodology name were removed and rewritten in plain language across the homepage, Solutions Overview, Industries Overview, both comparison tables, every industry page, the FAQ, About, Our Process, Partners, Disclaimer, Acceptable Use Policy, and Contact pages. Nothing about the underlying methodology changed.

## The "Why GROWKINS" page rebuilt as a full authority page (round 21)

Substantially expanded to match the strategic depth of established competitors: Why Companies Choose GROWKINS, Our Outbound Philosophy, Our Multichannel Approach (all 5 real channels), Our Campaign Methodology, Quality Standards, Reporting & Communication, Technology & Tools, and Why We're Different. Every section describes how the business already operates — nothing new was claimed.

## Cold Calling added as a core service, homepage hero rewritten (round 20)

Cold Calling added as a full, real service (trained callers, customized scripts, objection handling, voicemail strategy, live qualification, follow-up calls, CRM updates), positioned after Cold Email Outreach rather than appended last. Homepage hero rewritten to "Turn Target Accounts Into Qualified Sales Opportunities," naming all five real channels (superseded on the headline specifically by round 25).

## A working outbound ROI calculator, homepage teaser + dedicated page (round 19)

A dual-tab calculator (ROI Calculator + Outbound Cost Estimator) at a dedicated root-level URL, plus a simplified homepage teaser. Every number computes live from visitor input — nothing is a static example presented as a real result.

## Industry-native language across all 14 shared-template industry pages (round 18)

Real domain terminology instead of interchangeable generic phrasing, with no new claims about GROWKINS' own results.

## Outcome-first rewrite of the homepage hero and all seven service-page openers (round 17)

Rewritten to lead with the visitor's problem or the cost of the status quo.

## Small, verified SEO and clarity fixes from a full-site audit (round 16)

Homepage title and meta description lengths corrected; deliverables added to Our Process; a reassurance strip added to Contact.

## Mobile responsiveness verified on the homepage flow diagram (round 15)

Tested at 375–921px with zero horizontal overflow at any width.

## A plain, unbranded methodology visual on the homepage (round 14)

The shared seven-step process renders as a horizontal flow diagram — no trademark or new performance claims.

## Homepage CTA upgraded, worksheet closing pitch strengthened (round 13)

Superseded on the homepage hero specifically by round 20 (and round 25); the worksheet download is still live elsewhere on the homepage.

## A real, downloadable ICP Worksheet (round 12)

A genuine 6-page ICP Worksheet PDF wired into the Resources page and homepage with real download links.

## Rebrand to GROWKINS, plus a round of expert-audit fixes (round 11)

The site was rebranded from "Meridian" to "GROWKINS" everywhere (round 24 found and fixed one leftover internal route/filename from this rebrand).

## Launch-readiness fixes: no fabricated proof, no visible placeholders, real domain (rounds 9–10)

All fabricated case-study numbers, testimonials, and sample client logos removed entirely.

## One clear message: a premium outbound growth company (round 8)

All seven service pages standardized to the same eight-section pattern (round 24 found and closed a partial gap in this standardization).

## Repositioned around services, not frameworks (round 7)

Six framework-branded pages removed; RevenueOS™ reduced (at the time) to a single mention — fully retired in round 22.

## Earlier rounds (1–6)

Homepage and industry-page structure were built and iteratively refined.

## Documentation package (delivered round 21, updated rounds 22–25)

A companion `GROWKINS-Website-Documentation.docx` generated directly from the codebase: a full website inventory, a content and conversion map, a future-improvements backlog (requires real business proof / can be built without proof / technical maintenance / optional long-term growth), a proof-placement checklist, technical handoff notes, and a current-baseline record.

## Pages are organized into folders
- `/` (root) — `index.html` (homepage), `outbound-roi-calculator.html`, `sitemap.xml`, `robots.txt`, `assets/`
- `/services/`, `/industries/`, `/resources/`, `/company/`, `/legal/`
- `/assets/downloads/` — real downloadable resources (currently: the ICP Worksheet PDF)

Verified this round with: a full `node --check` syntax pass, a Playwright sweep of all 43 SPA routes (zero console/page errors, confirming the new hero copy renders correctly), a link-checker across all 43 static pages (5,552 relative link/asset references, zero broken), and a second Playwright sweep of the static `dist/` files.

## Before launch
1. **Connect the contact and newsletter forms to a real CRM or email platform.** Top launch blocker.
2. **Set real legal effective dates** on the legal pages.
3. **Publish real case studies, testimonials, and proof as they become available** — see the documentation package's Proof Placement Checklist.
4. **Decide on FAQ policy answers** for guaranteed appointment volume, international coverage, data ownership, and pause/cancellation terms.
5. **Consider narrowing the homepage's industry emphasis** once you have proof there.
6. Add real client logos, a ratings/review badge, and a "companies served" figure once you have them.
7. Consider a founder story once real material exists.
8. Confirm the tech stack referenced on industry pages matches what GROWKINS actually uses before showing any tool logos as trust signals.
9. Comparison pages (In-House vs. Outsourced SDR, etc.) remain available whenever there's appetite for them.
10. Consider expanding Resources beyond the ICP Worksheet with more real templates.
11. Treat the ROI calculator's cost-estimator weighting as a first draft if it doesn't match your actual pricing model.
12. Clean up the four dead `INDUSTRY_FULL` entries (SaaS, AI, Cybersecurity, Manufacturing) — source-file hygiene only.
13. Partners page has no dedicated partner-application form yet, and is reachable only from the footer, not the primary nav.
14. Terms of Service is referenced in the footer as plain, unlinked text — build when copy is provided.
15. Cookie Policy is pending — only partial copy submitted so far.
16. If your static host doesn't auto-serve `folder/index.html` at `folder/`, filenames stay as-is.
17. Careers page currently states there are no open roles — update once hiring.
18. ~~Resolve the remaining "RevenueOS™" mentions~~ — done in round 22.
19. Consider whether Our Process and The GROWKINS Method should eventually be merged or kept distinct long-term — they currently serve different reader intents and cross-link to each other.
20. **A site-wide "Related Services / Related Industries / Related Resources" internal-linking block** was recommended in round 24's audit but not built — it's a real SEO/UX improvement, but needs a scoping decision on which pages get it and what shows on pages where "related content" isn't obvious (e.g. legal pages) before building it consistently.
21. Standardizing every industry page to an explicit pain-points/buying-triggers/decision-makers/channels/FAQ/CTA structure was also recommended — the 14 pages already share one template with real domain-specific content (round 18), but don't yet break out "buying triggers" and "decision-makers targeted" as their own explicit subsections.
22. A "Preferred Contact Method" field (Email/Phone/Zoom/Google Meet) was recommended for the Contact form — small, safe addition, not yet built.
23. **Fix the pre-existing JS syntax issue in the newsletter and demo-request form handlers** (flagged in round 26) — unrelated to this or the prior round's visual work, but still open.
24. **Four pre-existing narrow-viewport horizontal-overflow cases** were found during round 27's QA sweep — present since before round 26, unrelated to the icon/infographic work: the Why GROWKINS page's channel-icon row (≤430px), the Our Process page's phase-rail layout (≤430px), and the Telecommunications and Media Production industry pages' segment-pill rows (≤360px). None were introduced by rounds 26–27; see the QA report for exact figures.
